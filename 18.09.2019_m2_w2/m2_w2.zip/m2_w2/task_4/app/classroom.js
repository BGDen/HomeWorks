export default class Classroom{
  constructor(name = 0, numSeats = 0, faculty = 'noname'){
    this.name = name;
    this.numSeats = numSeats;
    this.faculty = faculty;
  }
}