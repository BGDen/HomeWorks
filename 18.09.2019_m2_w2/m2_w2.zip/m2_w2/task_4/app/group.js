export default class Group{
  constructor(name = 'noname', students = 0, faculty = 'noname'){
      this.name = name;
      this.students = students;
      this.faculty = faculty;
  }
}